//////////////////
// JavaScript for Posts
/////////////////

$(function() {
    $('.menu_icon').click(function() {
        $(this).next().toggle(); 
    })
})

